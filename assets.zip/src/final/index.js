import Router from './Router';

export default Router;
