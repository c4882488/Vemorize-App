import React from 'react';
import {Router, Tabs, Stack, Scene} from 'react-native-router-flux';
import wordList from './wordList';
import challengeList from './challengeList';
import wordFrom from './wordForm';

const Route = () => {
  return (
    <Router>
      <Tabs
        headerLayoutPreset="center"
        tabBarPosition="bottom"
        // showLabel={false}
      >
        <Stack key="root" title="singleWord">
          <Scene
            key="singleWord"
            component={wordList}
            title="Single Word"
            initial
          />
        </Stack>
        <Scene key="wordFrom" component={wordFrom} title="New Add word" />
        <Scene
          key="challengeList"
          component={challengeList}
          title="Challenge"
        />
      </Tabs>
    </Router>
  );
};

export default Route;
