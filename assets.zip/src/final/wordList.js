import React from 'react';
import {View, Text} from 'react-native';

class wordList extends React.Component {
  render() {
    return (
      <View>
        <Text>wordList</Text>
      </View>
    );
  }
}

export default wordList;
