import React from 'react';
import {Text, View} from 'react-native';

class wordForm extends React.Component {
  render() {
    return (
      <View>
        <Text>challengeList</Text>
      </View>
    );
  }
}

export default wordForm;
