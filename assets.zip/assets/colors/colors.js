const colors = {
  black: '#26241e',
  yellow: '#fada6f',
  background: '#FFF7DC',
  navBackground: '#ffeaa4',
  blackgray: '#b8b8b8',
  iconblack: '#4e4b40',
  icongray: '#d0cfc5',
};

export default colors;
