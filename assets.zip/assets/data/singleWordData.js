const singleWord = [
  {
    id: 1,
    word: 'Apple',
    pos: 'n.',
    mean: '蘋果',
    class: '水果',
    color: 'red',
  },
  {
    id: 2,
    word: 'Banana',
    pos: 'n.',
    mean: '香蕉',
    class: '水果',
    color: 'red',
  },
  {
    id: 3,
    word: 'Orange',
    pos: 'n.',
    mean: '橘子',
    class: '水果',
    color: 'red',
  },
  {
    id: 4,
    word: 'pear',
    pos: 'n.',
    mean: '梨子',
    class: '水果',
    color: 'red',
  },
];

export default singleWord;
