const wordClass = [
  {
    id: 1,
    class: '水果',
  },
  {
    id: 2,
    class: '動物',
  },
  {
    id: 3,
    class: '物品',
  },
  {
    id: 4,
    class: '方向',
  },
  {
    id: 5,
    class: '時間',
  },
];

export default wordClass;
