import App from './src/final';

export default App;
